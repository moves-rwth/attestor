#python -m SimpleHTTPServer 8002

python -m http.server 8002
